var searchData=
[
  ['data',['data',['../struct_o_s_s_1_1data.html',1,'OSS']]],
  ['dateutil',['DateUtil',['../class_o_s_s_1_1_date_util.html',1,'OSS']]],
  ['defaultserviceclient',['DefaultServiceClient',['../class_o_s_s_1_1_default_service_client.html',1,'OSS']]],
  ['deleteobjectsresult',['DeleteObjectsResult',['../class_o_s_s_1_1_delete_objects_result.html',1,'OSS']]]
];
