var searchData=
[
  ['initiatemultipartuploadrequest',['InitiateMultipartUploadRequest',['../class_o_s_s_1_1_initiate_multipart_upload_request.html',1,'OSS']]],
  ['initiatemultipartuploadresult',['InitiateMultipartUploadResult',['../class_o_s_s_1_1_initiate_multipart_upload_result.html',1,'OSS']]]
];
