var searchData=
[
  ['listmultipartuploadsrequest',['ListMultipartUploadsRequest',['../class_o_s_s_1_1_list_multipart_uploads_request.html',1,'OSS']]],
  ['listobjectsrequest',['ListObjectsRequest',['../class_o_s_s_1_1_list_objects_request.html',1,'OSS']]],
  ['listpartsrequest',['ListPartsRequest',['../class_o_s_s_1_1_list_parts_request.html',1,'OSS']]]
];
