var searchData=
[
  ['uploadpartrequest',['UploadPartRequest',['../class_o_s_s_1_1_upload_part_request.html',1,'OSS']]],
  ['uploadpartresult',['UploadPartResult',['../class_o_s_s_1_1_upload_part_result.html',1,'OSS']]]
];
