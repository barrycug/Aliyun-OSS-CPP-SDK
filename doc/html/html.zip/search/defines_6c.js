var searchData=
[
  ['legal_5falt',['LEGAL_ALT',['../strptime_8h.html#a96e322f2a4f6f20edc867e27bf8aa7ef',1,'strptime.h']]],
  ['lenstr',['LENSTR',['../xml_parser_8cpp.html#a183cfe5a3825f1e0bc691ab934d79323',1,'xmlParser.cpp']]]
];
