var searchData=
[
  ['tm_5fyear_5fbase',['TM_YEAR_BASE',['../strptime_8h.html#a0b24352233a7c91b5e627d2a26ffefb3',1,'strptime.h']]],
  ['true',['TRUE',['../xml_parser_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'xmlParser.h']]]
];
