var searchData=
[
  ['xml_5fisspacechar',['XML_isSPACECHAR',['../xml_parser_8cpp.html#a191879a1c25a6c31e1b4141c1047c8a2',1,'xmlParser.cpp']]],
  ['xmlchar',['XMLCHAR',['../xml_parser_8h.html#a9f587fbd233e721e8818a3bf8102838f',1,'xmlParser.h']]],
  ['xmlcstr',['XMLCSTR',['../xml_parser_8h.html#acdb0d6fd8dd596384b438d86cfb2b182',1,'xmlParser.h']]],
  ['xmldllentry',['XMLDLLENTRY',['../xml_parser_8h.html#a990c86ec1cdbf675604a1a321d852063',1,'XMLDLLENTRY():&#160;xmlParser.h'],['../xml_parser_8h.html#a990c86ec1cdbf675604a1a321d852063',1,'XMLDLLENTRY():&#160;xmlParser.h']]],
  ['xmlstr',['XMLSTR',['../xml_parser_8h.html#a849d96105aa0c8f64b5c10d9151a3cdc',1,'xmlParser.h']]]
];
