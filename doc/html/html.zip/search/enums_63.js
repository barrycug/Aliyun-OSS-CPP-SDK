var searchData=
[
  ['cannedacltype',['CannedAclType',['../_o_s_s_api_8h.html#a9cfe8bb854494b6024442614b372ee35',1,'OSSApi.h']]],
  ['chartset',['Chartset',['../_o_s_s_api_8h.html#aa4b089c92291ec7e6d91aa9dfedbdeba',1,'OSSApi.h']]]
];
