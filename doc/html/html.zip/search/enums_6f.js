var searchData=
[
  ['oss_5fresultcode',['OSS_RESULTCODE',['../_o_s_s_api_8h.html#afad70044f7e0276cf1a71f4944acf356',1,'OSSApi.h']]]
];
