var searchData=
[
  ['httpmethod_5fdelete',['HttpMethod_DELETE',['../_o_s_s_api_8h.html#a4353a75834bb35c4acd80b51434eef59a02bd892fecfaa22a33926fa24054efda',1,'OSSApi.h']]],
  ['httpmethod_5fget',['HttpMethod_GET',['../_o_s_s_api_8h.html#a4353a75834bb35c4acd80b51434eef59a15157b100d9d3b6616eb9db7b40159c3',1,'OSSApi.h']]],
  ['httpmethod_5fhead',['HttpMethod_HEAD',['../_o_s_s_api_8h.html#a4353a75834bb35c4acd80b51434eef59a2d15595e95dcd80e98be57c4c943c24a',1,'OSSApi.h']]],
  ['httpmethod_5fpost',['HttpMethod_POST',['../_o_s_s_api_8h.html#a4353a75834bb35c4acd80b51434eef59a3b15a5236f67cfa20f5ee092442c340c',1,'OSSApi.h']]],
  ['httpmethod_5fput',['HttpMethod_PUT',['../_o_s_s_api_8h.html#a4353a75834bb35c4acd80b51434eef59abd8434eec4b19c00cc3bc91ad73b6d8d',1,'OSSApi.h']]],
  ['httpresult_5fcantconnect',['HTTPRESULT_CANTCONNECT',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3deaa3ec44a3933cb9828df6e0419b6aa5d7',1,'OSSApi.h']]],
  ['httpresult_5fcantresolve',['HTTPRESULT_CANTRESOLVE',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3dea6f6cdca9c049d8fa6c1a4fac5339076d',1,'OSSApi.h']]],
  ['httpresult_5ferror',['HTTPRESULT_ERROR',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3dea669ef1c7148bc53d88c3de49ed202023',1,'OSSApi.h']]],
  ['httpresult_5ffail',['HTTPRESULT_FAIL',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3deac20aa32be03f3d80de4f517fa55ae3fb',1,'OSSApi.h']]],
  ['httpresult_5fok',['HTTPRESULT_OK',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3deadfd9a08e42e7bb6caa3b777e20afde9d',1,'OSSApi.h']]],
  ['httpresult_5fopiton_5ferr',['HTTPRESULT_OPITON_ERR',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3deaa3cc507ff7e3d8774fe81fc8707a8330',1,'OSSApi.h']]],
  ['httpresult_5ftimeout',['HTTPRESULT_TIMEOUT',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3deac91ca24f177479750e61477bfea9770f',1,'OSSApi.h']]],
  ['httpresult_5ftoolagre',['HTTPRESULT_TOOLAGRE',['../_o_s_s_api_8h.html#a5801c37ead7e55ab7b64caa594bda3deae891b179fc8fd3d5c5cda6710500c79a',1,'OSSApi.h']]]
];
