var searchData=
[
  ['abortmultipartupload',['AbortMultipartUpload',['../class_o_s_s_1_1_o_s_s_client.html#a2a32ad8600f7a09849554e2d8c4761d3',1,'OSS::OSSClient::AbortMultipartUpload()'],['../class_o_s_s_1_1_o_s_s_multipart_operation.html#a15d4903e6580558e3907c691c4df604f',1,'OSS::OSSMultipartOperation::AbortMultipartUpload()']]],
  ['abortmultipartupload_5fasync',['AbortMultipartUpload_Async',['../class_o_s_s_1_1_o_s_s_client.html#a7060cdd637337d83d269e4e080d65295',1,'OSS::OSSClient::AbortMultipartUpload_Async()'],['../class_o_s_s_1_1_o_s_s_multipart_operation.html#ada31e5cd330eada42e13f43c2656b3e4',1,'OSS::OSSMultipartOperation::AbortMultipartUpload_Async()']]],
  ['abortmultipartuploadrequest',['AbortMultipartUploadRequest',['../class_o_s_s_1_1_abort_multipart_upload_request.html#a10eb8d263516b30b0c93b2f8b4873ad8',1,'OSS::AbortMultipartUploadRequest']]],
  ['addattribute',['addAttribute',['../struct_x_m_l_node.html#a7938c43648ce7ed32efc9f0a5e3b5d2c',1,'XMLNode']]],
  ['addattribute_5fwosd',['addAttribute_WOSD',['../struct_x_m_l_node.html#a45d1c57025ef576313d7412920d7a326',1,'XMLNode']]],
  ['addchild',['addChild',['../struct_x_m_l_node.html#a51baa56a48f69cdea6f41ed38a2cbadd',1,'XMLNode::addChild(XMLCSTR lpszName, char isDeclaration=FALSE, XMLElementPosition pos=-1)'],['../struct_x_m_l_node.html#a37c862f1d4a86f95417f97ceaa40d0fa',1,'XMLNode::addChild(XMLNode nodeToAdd, XMLElementPosition pos=-1)']]],
  ['addchild_5fwosd',['addChild_WOSD',['../struct_x_m_l_node.html#a24b13602fdff0194b087df4eaf28e703',1,'XMLNode']]],
  ['addclear',['addClear',['../struct_x_m_l_node.html#ab933d009523f94a4fd1dee09e1a3c931',1,'XMLNode']]],
  ['addclear_5fwosd',['addClear_WOSD',['../struct_x_m_l_node.html#ad92450b1a8380678f52ad53a54fd068c',1,'XMLNode']]],
  ['addheader',['addHeader',['../class_o_s_s_1_1_http_message.html#a91acd6f8a928f2074db855e1df84f6b6',1,'OSS::HttpMessage::addHeader()'],['../class_o_s_s_1_1_object_metadata.html#a069f4c031d58761fb099d0297793b7a8',1,'OSS::ObjectMetadata::AddHeader()']]],
  ['addlistheader',['AddListHeader',['../class_o_s_s_1_1_o_s_s_util.html#a105710e9845d7b571cb24fae52dbb5d2',1,'OSS::OSSUtil']]],
  ['addpostdata',['addPostData',['../class_o_s_s_1_1_h_t_t_p_request.html#a9b2b1feb7c52a48f81baaad92e5dd760',1,'OSS::HTTPRequest']]],
  ['addrequestheader',['addRequestHeader',['../class_o_s_s_1_1_h_t_t_p_request.html#a5a76649f02e6b316ec88668b6d190635',1,'OSS::HTTPRequest']]],
  ['addtext',['addText',['../struct_x_m_l_node.html#a1de718e237befa215381d294fc644f11',1,'XMLNode']]],
  ['addtext_5fwosd',['addText_WOSD',['../struct_x_m_l_node.html#a90944eacfeb994486e3ca83a68c35b6a',1,'XMLNode']]],
  ['addusermetadata',['AddUserMetadata',['../class_o_s_s_1_1_object_metadata.html#afba2e0d6ef3aca8c75469dfa1a552346',1,'OSS::ObjectMetadata']]],
  ['asyncdohttpdelete',['AsyncDoHttpDelete',['../class_o_s_s_1_1_h_t_t_p_request.html#a410e8c60ae6d42d0b79aa1e09b02c06b',1,'OSS::HTTPRequest']]],
  ['asyncdohttpget',['AsyncDoHttpGet',['../class_o_s_s_1_1_h_t_t_p_request.html#a5ac7ddf980ae6c1c0606072b30799a51',1,'OSS::HTTPRequest']]],
  ['asyncdohttphead',['AsyncDoHttpHead',['../class_o_s_s_1_1_h_t_t_p_request.html#a041cf485fd1727e55dfbd5f31feb7d7a',1,'OSS::HTTPRequest']]],
  ['asyncdohttppost',['AsyncDoHttpPost',['../class_o_s_s_1_1_h_t_t_p_request.html#a7716ff4316dccd02ed27c8724ccf9e75',1,'OSS::HTTPRequest']]],
  ['asyncdohttpput',['AsyncDoHttpPut',['../class_o_s_s_1_1_h_t_t_p_request.html#aa7f0bb062783540921dc2290eaeac78d',1,'OSS::HTTPRequest']]]
];
