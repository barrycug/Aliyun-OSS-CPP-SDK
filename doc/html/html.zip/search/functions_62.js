var searchData=
[
  ['base64_5fdecode',['base64_decode',['../base64_8cpp.html#a70c8cda20425a7870ddfb58ff3cff5eb',1,'base64_decode(std::string const &amp;encoded_string):&#160;base64.cpp'],['../base64_8h.html#a106490c99e374daddc9575ce945d8ba0',1,'base64_decode(std::string const &amp;s):&#160;base64.cpp']]],
  ['base64_5fencode',['base64_encode',['../base64_8cpp.html#af218d8d076a8a9ee46abf1e5c368c84f',1,'base64_encode(unsigned char const *bytes_to_encode, unsigned int in_len):&#160;base64.cpp'],['../base64_8h.html#a3409fa3795f44deb77fe72094084d020',1,'base64_encode(unsigned char const *, unsigned int len):&#160;base64.cpp']]],
  ['bucket',['Bucket',['../class_o_s_s_1_1_bucket.html#aeb3151544b9f6368b29e6a653f79c2c1',1,'OSS::Bucket::Bucket(void)'],['../class_o_s_s_1_1_bucket.html#abc4d778bffa921fbaf1686ed9734eb6c',1,'OSS::Bucket::Bucket(string &amp;strXML)']]],
  ['buckets',['Buckets',['../class_o_s_s_1_1_buckets.html#a10d1d4224c2fdffd86de1ac543a15ec4',1,'OSS::Buckets::Buckets(void)'],['../class_o_s_s_1_1_buckets.html#a8812ada6c1ef302eb78f87243d656927',1,'OSS::Buckets::Buckets(string &amp;strXML)']]],
  ['buildcanonicalstring',['buildCanonicalString',['../class_o_s_s_1_1_sign_util.html#a6c0ddd443f3068d1a9556104d7bf88f2',1,'OSS::SignUtil']]]
];
