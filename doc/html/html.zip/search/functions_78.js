var searchData=
[
  ['xmlnode',['XMLNode',['../struct_x_m_l_node.html#a138099a1355b9d4103c239d9042adad3',1,'XMLNode::XMLNode(const XMLNode &amp;A)'],['../struct_x_m_l_node.html#a719b115adfb642594107854189559ff2',1,'XMLNode::XMLNode()']]],
  ['xmlparserbase64tool',['XMLParserBase64Tool',['../struct_x_m_l_parser_base64_tool.html#a5e3ba8eaaa2876a336ae5e222312caf9',1,'XMLParserBase64Tool']]],
  ['xmltoa',['xmltoa',['../xml_parser_8cpp.html#a48d45f5d43c6f066ee175003afd71bab',1,'xmltoa(XMLCSTR t, XMLCSTR v):&#160;xmlParser.cpp'],['../xml_parser_8h.html#a20998546f61a5d41ed3fe4553702473a',1,'xmltoa(XMLCSTR xmlString, XMLCSTR defautValue=_CXML(&quot;&quot;)):&#160;xmlParser.cpp']]],
  ['xmltob',['xmltob',['../xml_parser_8cpp.html#ac437e5eaeaa314f4d183954307d87e5f',1,'xmltob(XMLCSTR t, char v):&#160;xmlParser.cpp'],['../xml_parser_8h.html#ac93e613b4563072bf7b43f91d2696c75',1,'xmltob(XMLCSTR xmlString, char defautValue=0):&#160;xmlParser.cpp']]],
  ['xmltoc',['xmltoc',['../xml_parser_8cpp.html#abe8af6345a2e4b6c24114cb6ab10634a',1,'xmltoc(XMLCSTR t, const XMLCHAR v):&#160;xmlParser.cpp'],['../xml_parser_8h.html#aa929f34f436c3466e66196e5e2091e73',1,'xmltoc(XMLCSTR xmlString, const XMLCHAR defautValue=_CXML(&apos;\0&apos;)):&#160;xmlParser.cpp']]],
  ['xmltof',['xmltof',['../xml_parser_8cpp.html#a3da27f643274c46145a2acb2702144b3',1,'xmltof(XMLCSTR t, double v):&#160;xmlParser.cpp'],['../xml_parser_8h.html#af820a1a0f8055c8e4a006a566be9500a',1,'xmltof(XMLCSTR xmlString, double defautValue=.0):&#160;xmlParser.cpp']]],
  ['xmltoi',['xmltoi',['../xml_parser_8cpp.html#a65fb3ed279d9ca00a4a3ba5b0bf54dc7',1,'xmltoi(XMLCSTR t, int v):&#160;xmlParser.cpp'],['../xml_parser_8h.html#a17b00a11ddc49e8e253160cc56d6377f',1,'xmltoi(XMLCSTR xmlString, int defautValue=0):&#160;xmlParser.cpp']]],
  ['xmltol',['xmltol',['../xml_parser_8cpp.html#a801c1bbf692d1f29a4b927ceb1cd6112',1,'xmltol(XMLCSTR t, long v):&#160;xmlParser.cpp'],['../xml_parser_8h.html#ab69be88d6b554476470e7a1e6ec23589',1,'xmltol(XMLCSTR xmlString, long defautValue=0):&#160;xmlParser.cpp']]]
];
