var searchData=
[
  ['creating_20from_20scratch_20a_20xmlnode_20structure',['Creating from scratch a XMLNode structure',['../group__creation.html',1,'']]],
  ['create_20or_20update_20the_20xmlnode_20structure',['Create or Update the XMLNode structure',['../group__xml_modify.html',1,'']]]
];
