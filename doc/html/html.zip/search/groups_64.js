var searchData=
[
  ['deleting_20nodes_20or_20attributes',['Deleting Nodes or Attributes',['../group__xml_delete.html',1,'']]]
];
