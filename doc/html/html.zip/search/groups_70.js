var searchData=
[
  ['parsing_20xml_20files_2fstrings_20to_20an_20xmlnode_20structure_20and_20rendering_20xmlnode_27s_20to_20files_2fstring_2e',['Parsing XML files/strings to an XMLNode structure and Rendering XMLNode&apos;s to files/string.',['../group__conversions.html',1,'']]],
  ['position_20helper_20functions_20_28use_20in_20conjunction_20with_20the_20update_26add_20functions',['Position helper functions (use in conjunction with the update&amp;add functions',['../group__xml_position.html',1,'']]]
];
