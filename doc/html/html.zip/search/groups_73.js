var searchData=
[
  ['string_20allocation_2ffree_20functions',['String Allocation/Free functions',['../group___string_alloc.html',1,'']]]
];
