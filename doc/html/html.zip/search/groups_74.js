var searchData=
[
  ['the_20xml_20parser',['The XML parser',['../group___x_m_l_parser_general.html',1,'']]]
];
